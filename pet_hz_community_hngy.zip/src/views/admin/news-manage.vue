<template>
  <div>
      资讯管理
  </div>
</template>

<script>
export default {}
</script>

<style scoped></style>
